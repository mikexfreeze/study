# Waterfall-horizontal

## Note
  * This project is based on [Waterfall](https://github.com/bingdian/waterfall)
  * This project is a part of project [Qicaiwu](https://github.com/senntyou/qicaiwu)
    
## Documentation
  * [Doc](docs/index.md)
  
## Demo
  * [infinite scroll](http://senntyou.github.io/waterfall-horizontal/)